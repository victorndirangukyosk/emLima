<?php

$_['heading_title']     = 'Thank you for shopping with Payu ';
$_['text_title']        = 'PayU Checkout';
$_['text_response']     = 'Response from payu:';
$_['text_success']      = 'your payment was successfully received.';
$_['text_success_wait'] = '';
$_['text_failure']      = 'Your payment has been failured';
$_['text_cancelled']    = 'Your payment has been cancelled';
$_['text_pending']      = 'Your payment has been pending';
$_['text_failure_wait'] = '';										  
?>