<?php

$_['text_find_account']  = 'Find Your Account?';
$_['text_forget']  = 'Enviado';
$_['text_enter_email_address']  = 'Endereço de e-mail';
$_['text_enter_password']  = 'Senha';
$_['text_move_next']  = 'próximo';
$_['text_move_Next']  = 'Próximo';
$_['text_success_verification']  = 'Verifição realizada com sucesso';
$_['text_enter_you_agree']  = 'Você concorda com:';
$_['text_terms_of_service']  = 'Termos e Condições de Uso';
$_['text_privacy_policy']  = 'Política de Privacidade';

