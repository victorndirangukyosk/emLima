<?php

$_['text_welcome_message']  			= 'Bem-Vindo ao SUACOMPRAONLINE';
$_['text_or']  = 'ou';
$_['text_continue_with_facebook']  		= 'Entrar com Facebook';
$_['text_continue_with_twitter']  		= 'Entrar com Twitter';
$_['text_continue_with_google']  = 'Entrar com Google';
$_['text_log_in']     					='Entrar';
$_['text_enter_you_agree']  			= 'Você concorda com nosso';
$_['text_terms_of_service']  			= 'Termo de Uso';
$_['text_privacy_policy']  				= 'Política de Privacidade';
$_['text_have_account']  				= 'Já tem uma Conta? ';

?>