<?php

$_['text_number_verification']  = 'Código de Verificação';
$_['text_enter_number_to_login']  = 'Digite seu número de telefone para entrar/ cadastrar-se';
$_['text_enter_email_address']  = 'Endereço de Email';
$_['text_enter_password']  = 'Senha';
$_['text_move_next']  = 'próximo';
$_['text_move_Next']  = 'Próximo';
$_['text_or']  = 'ou';
$_['text_log_in']     ='Entrar';
$_['text_login']     ='Entrar';
$_['text_continue_with_facebook']  = 'Entrar com Facebook';
$_['text_continue_with_twitter']  = 'Entrar com Twitter';
$_['text_continue_with_google']   = 'Entrar com Google';
$_['text_back']  = 'Voltar';
$_['text_code_verification']  = 'Código de Verificação';
$_['text_enter_code_in_area']  = 'Digite seu código abaixo.';
$_['text_enter_phone']  = 'Telefone';
$_['text_success_verification']  = 'Verificação efetuada com sucesso';
$_['text_enter_you_agree']  = 'Você concorda com nosso';
$_['text_terms_of_service']  = 'Termo de Uso';
$_['text_privacy_policy']  = 'Política de Privacidade';
$_['text_welcome_message']  = 'Bem-Vindo ao SUACOMPRAONLINE';
$_['text_have_account']  = 'Já tem uma Conta? ';
$_['text_forget_password']  = 'Esqueceu sua senha?';

?>