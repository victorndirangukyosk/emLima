
<?php
// heading
$_['heading_title']    = 'SUACOMPRAONLINE - Um novo jeito de fazer compras';

//text
$_['text_open_store']  = 'Seja um Parceiro';
$_['text_store_working']  = 'Como Funciona?';
$_['text_delivery_detail']  = 'Sua compra em até 2 horas';
$_['text_enter_zipcode_title']  = 'Digite seu código postal e escolha o seu Mercado favorito.';
$_['text_enter_zipcode']  = 'Digite seu CEP';
$_['text_find_store']  = 'Find Store';
$_['text_have_account']  = 'Já tem uma conta? ';
$_['text_get_delivered']  = 'Seu Mercado Online';
$_['text_enter_password']  = 'Senha';
$_['text_move_next']  = 'próximo';
$_['text_move_Next']  = 'Próximo';
$_['text_code_verification']  = 'Código de Verificação';
$_['text_enter_code_in_area']  = 'Digite seu código abaixo.';
$_['text_enter_phone']  = 'Telefone';
$_['text_enter_you_agree']  = 'Você concorda com o nosso';
$_['text_terms_of_service']  = 'Termo de Uso';
$_['text_privacy_policy']  = 'Política de Privacidade';
$_['text_welcome_message']  = 'Bem-Vindo ao SUACOMPRAONLINE';
$_['text_welcome_user']  = 'Bem-vindo, ';


$_['text_account']       = 'Minha Conta';
$_['text_rewards']       = 'Meus Pontos de Fidelidade';
$_['text_orders']       = 'Meus Pedidos';
$_['text_refer']       = 'Indique um amigo';
$_['text_sign_out']    ='Finalizar Conta';
$_['text_sign_in']     ='Cadastrar-se';
$_['text_log_in']     ='Entrar';
$_['text_login']     ='Entrar';
$_['text_heading']     = 'Faça suas compras no mercado mais próximos e receba em até 2 horas.';
$_['text_heading2']    =  'Insira sua localização e escolha seu mercado antes de inicar as compras';
$_['text_heading3']    =   'Insira sua localização e escolha seu mercado'; 
$_['text_heading4']    =   'Ofertas';
$_['text_heading5']    =   'Comentários';
$_['text_heading6']    =   'Fale Conosco';

$_['text_logout']      = 'Sair';
$_['text_my_cash'] 	   = 'Meu Dinheiro';
$_['contactus']        = 'Fale Conosco';
$_['text_my_profile']  = 'Meu Perfil';
$_['label_my_address'] = 'Meus Endereços';
$_['text_register']    = 'Registrar';

$_['support'] = 'Suporte';
$_['faq']    = 'FAQ';
$_['call']  = 'Fale Conosco @';
$_['text']  = 'Oi,';                  

//label
$_['label_start']	   = 'Ir às Compras';
$_['label_name']       = 'Nome';
$_['label_email/phone']= 'Email/Telefone';
$_['label_msg']        = 'Mensagem';

$_['step1']	   		   = 'Free Home Delivery';
$_['step2']	   		   = 'Best Quality Assured';
$_['step3']	  		   = 'Store Price Guaranteed';
$_['step4']	  		   = 'Cash on Delivery';

//Button
$_['button_send']      = 'Enviar Mensagem';

?>