<?php

// Heading
$_['text_no_timeslot']                  = 'Infelizmente todo os nossos horários já estão preenchidos.Por favor, escolha outra data';
