<?php

// Text
$_['text_title']       = 'Entrega Agendada';
$_['text_description'] = 'Entrega Agendada';