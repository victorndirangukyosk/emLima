<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

//Heading
$_['heading_title'] 			= "Alterar Senha";
$_['heading_text'] 				= "Alterar Senha";

//Field Names
$_['label_current'] 			= "Senha Atual:";
$_['label_new'] 				= "Nova Senha:";
$_['label_retype'] 				= "Confirmar Senha:";

//Text
$_['text_success']				="Sua senha foi alterada com sucesso";


// Error
$_['error_current'] 			= 'Digite uma senha atual válida';
$_['error_check']				= 'Erro de verificação';
$_['error_new'] 				= 'Digite uma nova senha válida';
$_['error_retype'] 				= 'A senha nova de ser igual a de confirmação';
$_['error_password'] 			= 'Por favor, verifique a senha';
$_['error_change_fail'] 		= 'Não é possível alterar sua senha atual';
$_['error_warning']				= "";
$_['error_warning_message']		= "";

?>