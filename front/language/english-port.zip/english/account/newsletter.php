<?php


// Heading
$_['heading_title']    		= 'Autorização para Receber Novidades';

// Text
$_['text_account']     		= 'Conta';
$_['text_newsletter']  		= 'Novidades';
$_['text_success']     		= 'Sucesso: Sua autorização foi atualizada com sucesso!';
$_['text_yes']            	=  'Sim';
$_['text_no']             	=   'Não';

// Entry
$_['entry_newsletter'] 		= 'Autorizar';

?>